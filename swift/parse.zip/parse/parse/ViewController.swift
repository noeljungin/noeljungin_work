//
//  ViewController.swift
//  parse
//
//  Created by noel on 2018. 2. 21..
//  Copyright © 2018년 noel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var persons = [String : Any]()
    var ageArr = [String]()
    var jobArr = [String]()
    var nameArr = [String]()
    
    override func viewDidLoad(){
        super.viewDidLoad()
        let path = Bundle.main.path(forResource: "person", ofType: "json")
        if let data = try? String(contentsOfFile: path!).data(using: .utf8){
            let json = try!
            JSONSerialization.jsonObject(with: data!, options: []) as! [String : Any]
            print(json)
            persons = json
        }
        if let person = persons["person"] as? [[String : Any]]{
            for personIndex in person{
                ageArr.append(personIndex["age"] as! String)
                jobArr.append(personIndex["job"] as! String)
                nameArr.append(personIndex["name"] as! String)
            }
        }
    }
}

